



# Treasure-Pool
FFXI addon for both Ashita and Windower.
will show you what is in the treasure pool.
In Dynamis it will show relic armor slot & job.

![tpool](https://github.com/user-attachments/assets/31c97042-17b1-4024-827d-8d69542fddbd)

![dyna](https://github.com/user-attachments/assets/32f7ba65-fd09-4d98-8208-220947628906)

# TO-DO
- [ ] Windower Support
- [ ] Add item Timer. How long till item leaves pool
- [ ] Custom Item list's
- [ ] Custom Colors


DISCLAIMER: I am not part of the eden team. Just a player.
